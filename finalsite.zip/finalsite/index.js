// // Sticky navbar on scroll
// window.onscroll = function() {
//     var navigation = document.getElementsByClassName("navigation");
//     if (window.pageYOffset > 0) {
//       navigation.classList.add("sticky");
//     } else {
//       navigation.classList.remove("sticky");
//     }
//   };
  